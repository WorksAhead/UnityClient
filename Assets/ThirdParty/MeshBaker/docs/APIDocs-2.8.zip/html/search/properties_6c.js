var searchData=
[
  ['lightmapoption',['lightmapOption',['../class_digital_opus_1_1_m_b_1_1_core_1_1_m_b2___mesh_combiner.html#a84019f862a8a03faef161ac29ee83077',1,'DigitalOpus.MB.Core.MB2_MeshCombiner.lightmapOption()'],['../class_digital_opus_1_1_m_b_1_1_core_1_1_m_b2___multi_mesh_combiner.html#ae5462238f5c69410fe773a6f3f6384ff',1,'DigitalOpus.MB.Core.MB2_MultiMeshCombiner.lightmapOption()']]]
];
